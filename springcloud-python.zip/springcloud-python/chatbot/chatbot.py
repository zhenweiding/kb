import sys

import math

import tflearn

import tensorflow as tf

from tensorflow.python.ops import rnn_cell

from tensorflow.python.ops import rnn

import chardet

import numpy as np

import struct

def init_seq(input_file):
    """读取切好词的文本文件，加载全部词序列

    """

    file_object = open(input_file, 'r')

    vocab_dict = {}

    while True:

        question_seq = []

        answer_seq = []

        line = file_object.readline()

        if line:

            line_pair = line.split('|')

            line_question = line_pair[0]

            line_answer = line_pair[1]

            for word in line_question.decode('utf-8').split(' '):

                if word_vector_dict.has_key(word):
                    question_seq.append(word_vector_dict[word])

            for word in line_answer.decode('utf-8').split(' '):

                if word_vector_dict.has_key(word):
                    answer_seq.append(word_vector_dict[word])

        else:

            break

        question_seqs.append(question_seq)

        answer_seqs.append(answer_seq)

    file_object.close()


def generate_trainig_data(self):
    xy_data = []

    y_data = []

    for i in range(len(question_seqs)):

        question_seq = question_seqs[i]

        answer_seq = answer_seqs[i]

        if len(question_seq) < self.max_seq_len and len(answer_seq) < self.max_seq_len:
            sequence_xy = [np.zeros(self.word_vec_dim)] * (self.max_seq_len - len(question_seq)) + list(
                reversed(question_seq))

            sequence_y = answer_seq + [np.zeros(self.word_vec_dim)] * (self.max_seq_len - len(answer_seq))

            sequence_xy = sequence_xy + sequence_y

            sequence_y = [np.ones(self.word_vec_dim)] + sequence_y

            xy_data.append(sequence_xy)

            y_data.append(sequence_y)

    return np.array(xy_data), np.array(y_data)

