package com.chatbot.app;

import com.chatbot.app.bean.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
public class JavaController {
    @Autowired
    private RestTemplate restTemplate;
    
    @RequestMapping("/java-user")
    public String JavaUser() {
        return "{'username': 'java', 'password': 'java'}"  ;
    }

    @RequestMapping(value = "/getAnswer")
    public Message getAnswer(@RequestBody Message question) {
        ResponseEntity<String> responseEntity = restTemplate.getForEntity("http://py-sidecar:8001/getMsg?msg={1}", String.class, question.getQuestion());
        String answer = responseEntity.getBody();
        Message replyMessage = new Message();
        replyMessage.setAnswer(answer);
        replyMessage.setQuestion(question.getQuestion());

        return replyMessage;
    }

    @RequestMapping("/python-user")
    public String PythonUser() {
        return restTemplate.getForEntity("http://py-sidecar:8001/getUser", String.class).getBody();
    }

}
