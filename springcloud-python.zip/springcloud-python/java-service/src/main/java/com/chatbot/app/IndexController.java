package com.chatbot.app;

import com.chatbot.app.bean.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@Controller
public class IndexController {

    @RequestMapping("/")
    public String index() {
        return "index";
    }

}
